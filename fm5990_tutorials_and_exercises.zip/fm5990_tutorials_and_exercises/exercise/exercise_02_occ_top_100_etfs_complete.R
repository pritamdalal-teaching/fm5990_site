# Load all the libraries that you will need.
library(readr)
library(dplyr)
library(magrittr)
library(stringr)


# Read in the data from CSVs.
df_occ <- read_csv("data_occ_201808.csv")
df_etfs <- read_csv("data_etf_list.csv")
View(df_etfs)

df_etfs %>% filter(symbol == "VXX") %>% View()
df_etfs %>% filter(str_detect(segment, "Volatility"))
  
# Create a monthly volume report.
df_monthly_volume <- df_occ %>% group_by(underlying) %>% 
                                summarize(total_volume = sum(quantity)) %>%
                                arrange(desc(total_volume))
                                
View(df_monthly_volume)



# Look at df_etfs and examine the segment column. 
# Look for clues about whether the fund is volatility related.
View(df_etfs)


# Convert segment column of df_etfs to all lowercase letters.
df_etfs$segment <- df_etfs$segment %>% tolower()


# Isolate volatility etfs into a dataframe called df_vol_etfs.
df_vol_etfs <- df_etfs %>% dplyr::filter(str_detect(segment, "volatility"))


# Create a list of top 100 most liquid non-volatility ETFs.
# Call it df_top_100.
df_top_100 <- df_monthly_volume  %>%
              dplyr::filter(underlying %in% df_etfs$symbol) %>% 
              dplyr::filter(! underlying %in% df_vol_etfs$symbol) %>% 
              top_n(100, total_volume) %>% 
              arrange(desc(total_volume))

View(df_top_100)



# Create a dataframe consisting of the distinct by the df_top_100 symbols?
df_etfs %>% filter(symbol %in% df_top_100$underlying) %>% 
            distinct(segment) %>% 
            arrange(segment)


# Come up with a meaningful grouping of these segments.
df_etfs %>% filter(symbol %in% df_top_100$underlying) %>% 
            group_by(segment) %>%
            tally() %>% 
            arrange(desc(n)) %>% View()