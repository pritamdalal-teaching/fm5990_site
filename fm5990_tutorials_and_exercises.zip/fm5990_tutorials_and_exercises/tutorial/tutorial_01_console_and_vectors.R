################
## REAL TALK: ##
################
# 1. If you want to get anything out of this lecture:
#    TYPE ALONG WITH ME!!!!

# 2. Learning to program is not a passive activity. It doesn't 
#    matter if you don't understand what you are typing. All that 
#    matters is that you press buttton and things come out of the 
#    console.




#####################
## Tour of RStudio ##
#####################
# 1. Console - this is where you type single commands and R executes 
#              them immediately.

# 2. Source - this is where you write R scripts and other types
#             of files that have multiple lines of code in it.

# 3. Environment - shows all variables and function defined in the
#                  current R session.

# 4. Help - this pane is used to show a variety of output like help
#           and functions.           

# Real Talk: RStudio interface has a lot going on - too much in my
#            opinion.  I found this to be a little overwhelming at 
#            first.  Don't worry too much, we'll learn about what
#            we need, when we need it.




#######################################
## CONSOLE: Data and Varaible Basics ##
#######################################
# 1. You can do basic aritmetic operations on numbers at the console
##>  exp(0.01) - 1

# 2. You can assign variable values at the console
##> x <- exp(0.01) - 1

# 3. Notice that x now shows up in the enviroment window as a
#    variable.

# 3. Let's do some more variable assignment.
#> x <- "SPY"
##> y <- c(1, 2, 3)

## Notice how x was already assigned to a number, and then I re-
## it to a character.  This is a feature of R, you can assign
## and reassign freely.  This makes it easy to work with, but it
## also increases the the chance of an error.  This also reduces
## it's speed as a language.

# 4. From the console, you can also call functions that act on 
#    variables.
##> sum(y)





#############
## Scripts ##
#############
# 1. A lot of interesting things can be done by working in the con-
#    sole alone, but one limitation is that you have to type
#    a line of code and then execute it right away.

# 2. This is where scripts come in handy.

# 3. Scripts are multiple lines of code that are stored in a 
#   file wizth a name like "*.R".  The file that we are working 
#   with right now is a script.

# 4. Scripts are nice because they allow you to type out several 
#    lines of of code and then run them at once. 

# 5. Let's type three lines of code and then run them.
##> symbol <- "SPY"
##> price <- 287.50
##> vol <- 0.12
symbol <- "SPY"
price <- 287.50
vol <- 0.17



# **HOTKEY** select text: shift + arrow keys
# **HOTKEY** select the rest of line: shift + ctrl/cmd + arrow keys
# **HOTKEY** run selected code: ctrl/cmd + enter

# 5. We now see these three variables in our environment window.

# 6. Just to keep things organized, let's remove some variables 
#    that we will not use anymore.
##> rm(x); rm(y)





#############
## Vectors ##
#############
# 1. R is well suited for scientific computing, so working with 
#    vectors is very easy.

# 2. In fact, the three variables we just created - symbol, price,
#    and vol - are all vectors of length one. 

# 3.Vectors are the simplest kinds of variables in R. 

# 4. We use the c() function to manually create vectors

##> symbols <- c("SPY", "QQQ", "IWM", "DIA") 
##> prices <- c(287.50, 182.48, 171.59, 257.85) 
##> vols <- c(0.12, 0.15, 0.14, 0.13)
symbols <- c("SPY", "QQQ", "IWM", "DIA")
prices <- c(287.50, 182.48, 171.59, 257.85)
vols <- c(0.12, 0.15, 0.14, 0.13)

# 5. When you apply arithmetic operations to vectors, R does what 
#    you would expect and applies the operation component wise.
##> prices * (exp(vols) - 1) # market-implied annual 1-SD move
##> prices * (exp(vols/sqrt(252)) - 1) # market-implied daily 1-SD move 
prices * (exp(vols) - 1)

# 6. It's easy to create vectors of random numbers, which is 
#    something that we do often in quantitative finance. 

# 7. With the following bit of code we generate 1000 standard normal
#    random numbers.
##> standard_normal_vector <- rnorm(1000, 0, 1)
standard_normal_vector <- rnorm(10000, 0, 1)

# 8. When R was first developed, one of its major innovations was that
#    it allow for easy plotting of graphs.  This type of 
#    functionality has become standard all scientific computing 
#    languages.  It remains an important part of R.

# 9. Let's take a look at the histogram of the vector of normals
#    we just created and we can see the bell-curve we would expect.
##> hist(standard_normal_vector)
hist(standard_normal_vector)


# 10. As we can see, the plot is a little bit crude.  So we can add 
#     an argument called "breaks".
##> hist(standard_normal_vector, breaks = seq(-5, 5, 0.25))
hist(standard_normal_vector, breaks = seq(-5, 5, 0.25))

# 10. Don't worry if the above function looks a little weird.

# 11. This is a simple illustration of the type of fine-tuning that
#     is required in data visualization.  

# 12. Visualizatin is a big topic in Data Science and we will go 
#     into a lot more detail in FM 5990.
