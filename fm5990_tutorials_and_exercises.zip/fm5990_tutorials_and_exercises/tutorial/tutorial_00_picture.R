####################################
## Console: Install/Load Package) ##
####################################
# 1. R is free and open source and so it has been extended greatly
#    by user created "packages".

# 2. A package is simply a container of useful functions and data.

# 3. If a package doesn't exist on your computer, you first have to 
#    download it from the internet.  This can be done easily from
#    within RStudio.

# 4. Let's install a package from the console using the
#    install.packages function.
##> install.packages("magick")

# 5. After you run this you will see lots of output on your console.
#    Don't worry if you don't understand what's coming out - No one
#    does.

# 6. We now have the magick package downloaded on our computer.
#    But in order to use it we will need to load it into our current
#    R session.  

# 7. Let's use the library() function to load the magick package 
#    into our R session
##> library(magick)



################################
## CONSOLE: Working Directory ##
################################
# 1. At any given time in an R session, there is something called
#    the "working directory".

# 2. The working directory is the folder that R is looking at by 
#    default.

# 3. We can see what the current working directory is by using
#    the getwd() function in the console window.
##> getwd()

# 4. We can change the working directory using the function setwd().

# 5. Let's all change our working directory to the mfm-r-intro folder
#    that we saved on our Desktop.
##> setwd("/Users/Pritam/Desktop/mfm-r-intro/")

# 6. We can now access files in our working directory.  Try it.
##> print(image_read("not_ethical.png"))

# 7. I jumped ahead a couple of steps, so don't worry if you 
#    didn't get this last statement.  Just notice that I didn't 
#    have to use a full file-path for the function image_read().
