# loading packages
library(tidyverse)

# reading in the data
df_market_history <- read_csv("data_practice_market_history.csv")
df_option_history <- read_csv("data_practice_market_history.csv")

# this is just a test of some functionality that I found
# counting rows
df_count_test <- dplyr::count(df_market_history, trade_date)
sum(df_count_test$n)
df_market_history %>% nrow()

df_count_test <- dplyr::count(df_market_history, underlying, trade_date) 
df_count_test

help(dplry::count)

# stat_function
ggplot(mpg, aes(displ, hwy)) +
  geom_point(color = "grey") +
  stat_summary(fun.y = "mean", geom = "line", size = 1, linetype = "dashed")


# reversing the scale of an axis
# these are the liquidity metrics we are going to be using
df_liquidity <- 
df_market_history %>% 
  group_by(underlying) %>% 
  summarize(
            tot_volume = sum(volume)
            , avg_spread = mean(ask - bid)
            ) %>% 
  mutate(
         volume_rank = rank(-tot_volume)
         ,spread_rank = rank(avg_spread)
         )

View(df_liquidity)
df_liquidity %>% arrange(volume_rank) 

# reversing the rank scale and using th log10 scale on the avg_spread 
ggplot(
       data = df_liquidity
       ,mapping = aes(x = volume_rank, y = avg_spread)
       ) +
  geom_point(size = 0.75) +
  geom_smooth(size = 0.75, method = "lm") +
  scale_x_reverse() +
  scale_y_log10() 
  
# using log-log scale
ggplot(
  data = df_liquidity
  ,mapping = aes(x = tot_volume, y = avg_spread)
) +
  geom_point(size = 0.75) +
  geom_smooth(size = 0.75, method = "lm") +
  scale_x_log10() +
  scale_y_log10() +
  coord_flip() + 
  labs(
       title = "Liquity: Volume vs Spreads"
       , subtitle = "ETF Options Data from 8/16/2013 - 1/16/2014"
       , x = "total volume in contracts (log10 scale)"
       , y = "average spread in dollars (log10 scale)"
  )

  
##################  
## geom_label() ##
##################
# reading in data_options_intro.csv
df_intro <- read_csv("data_options_intro.csv")

ggplot(
       data = df_intro
       , mapping = aes(x = strike, y = implied_vol, color = underlying)
      ) + 
  geom_point() +
  geom_label(data = df_intro, aes(label = underlying))



  












