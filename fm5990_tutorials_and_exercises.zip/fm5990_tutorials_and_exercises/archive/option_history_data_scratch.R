library(readr)
library(dplyr)
library(tibble)


# creating market history csv with brute force
df_market_history <- read_csv("/Users/Pritam/files/R/equity_option_backtest/data_output/201309_market_history_top100_ETF.csv")

df_temp <- read_csv("/Users/Pritam/files/R/equity_option_backtest/data_output/201310_market_history_top100_ETF.csv")

df_market_history <- bind_rows(df_market_history, df_temp)

df_temp <- read_csv("/Users/Pritam/files/R/equity_option_backtest/data_output/201311_market_history_top100_ETF.csv")

df_market_history <- bind_rows(df_market_history, df_temp)

df_temp <- read_csv("/Users/Pritam/files/R/equity_option_backtest/data_output/201312_market_history_top100_ETF.csv")

df_market_history <- bind_rows(df_market_history, df_temp)

df_temp <- read_csv("/Users/Pritam/files/R/equity_option_backtest/data_output/201401_market_history_top100_ETF.csv")

df_market_history <- bind_rows(df_market_history, df_temp)

View(df_market_history)
df_market_history_cleaned <-  df_market_history %>%
                              select(-c(exchange, implied_vol, delta, bid_swap_rate, ask_swap_rate))

df_market_history_cleaned <- df_market_history_cleaned %>% 
                             rename(implied_vol=my_implied_vol
                                    ,delta=my_delta
                                    ,swap_rate=mid_swap_rate)


# creating option history csv with brute force
View(df_market_history_cleaned)

df_option_history <- read_csv("/Users/Pritam/files/R/equity_option_backtest/data_output/201309_option_history_top100_ETF.csv")

df_temp <- read_csv("/Users/Pritam/files/R/equity_option_backtest/data_output/201310_option_history_top100_ETF.csv")

df_option_history <- bind_rows(df_option_history, df_temp)

df_temp <- read_csv("/Users/Pritam/files/R/equity_option_backtest/data_output/201311_option_history_top100_ETF.csv")

df_option_history <- bind_rows(df_option_history, df_temp)

df_temp <- read_csv("/Users/Pritam/files/R/equity_option_backtest/data_output/201312_option_history_top100_ETF.csv")

df_option_history <- bind_rows(df_option_history, df_temp)

df_temp <- read_csv("/Users/Pritam/files/R/equity_option_backtest/data_output/201401_option_history_top100_ETF.csv")

df_option_history <- bind_rows(df_option_history, df_temp)

View(df_option_history)



# writing history files
df_market_history_cleaned %>% write_csv("data_practice_market_history.csv")
df_option_history %>% write_csv("data_practice_option_history.csv")