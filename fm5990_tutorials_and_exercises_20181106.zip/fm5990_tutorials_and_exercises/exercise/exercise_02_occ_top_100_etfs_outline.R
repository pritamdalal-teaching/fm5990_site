## Load all the libraries that you will need.



## Read in the data from CSVs.



## Create a monthly volume report.



## Look at df_etfs and examine the segment column. 
## Look for clues about whether the fund is volatility related.



## Convert segment column of df_etfs to all lowercase letters.



## Isolate volatility etfs into a dataframe called df_vol_etfs.



## Create a list of top 100 most liquid non-volatility ETFs.
## Call it df_top_100.




## Create a dataframe consisting of the distinct by the df_top_100 symbols?




## Come up with a meaningful grouping of these segments.


