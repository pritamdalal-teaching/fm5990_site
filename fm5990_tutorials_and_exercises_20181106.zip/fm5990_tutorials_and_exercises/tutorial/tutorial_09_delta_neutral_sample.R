#############
## context ##
#############
# The purpose of this tutorial is to apply our data manipulation and
# data visualization skills to understanding the Delta Neutral EOD 
# option prices file.  This file contains EOD bid/ask prices for all equity
# and ETF options that are listed. Recently this has been between 800K-900K
# options per day, on a little under 4,500 underlyings.



######################
## loading packages ##
######################
##> library(tidyverse)
##> library(lubridate)



#####################
## reading in data ##
#####################
##> df_daily <- read_csv("data_delta_neutral_sample.csv")
##> View(df_daily)



##############################
## converting dates columns ##
##############################
# 1) If we look at the two date columns, Expiration and DataDate, we
#    see that they are both characters.
##> mode(df_daily$Expiration)
##> mode(df_daily$DataDate)



# 2) There is a package in the Tidyverse that makes it a little bit easier
#    to work with dates.  It is called lubridate.
##> install.packages("lubridate")
##> library(lubridate)



# 3) There are a variety of functions, e.g. ymd(),  mdy(), dmy(), that 
#    convert non-dates into dates.  We will use one of these convert our 
#    columns to date times. (Note: in previous exercises we were using
#    base::as.Date() for this purpose - but let's use the tidyverse
#    whereever possible.)
##> df_daily$Expiration <- df_daily$Expiration %>% mdy()
##> df_daily$DataDate <- df_daily$DataDate %>% mdy()




#########################
## initial exploration ##
#########################
# 4) Let's see all the distinct DataDates.
##> df_daily %>% distinct(DataDate)



# 5) Let's see the distinct Expriations.
##> df_daily %>% distinct(Expiration) %>% arrange(Expiration)



# 6) Let's see the distinct underlyings.
##> df_daily %>% distinct(UnderlyingSymbol)



# 7) For each underlying, let's count the number of expiration there are
#    in the data.  Which underlying do you think will have the most
#    expirations?
##> df_daily %>% 
##>     group_by(UnderlyingSymbol) %>% 
##>     summarize(num_exps = n_distinct(Expiration)) %>% 
##>     arrange(desc(num_exps))



# 8) Let's explore the Flags column.  It takes two values * and W.
##> df_daily %>% distinct(Flags)
##>
##> df_daily %>% 
##>     filter(Flags == "W") %>% 
##>     distinct(UnderlyingSymbol)





## Exercise: SPXW is the only underlying symbol that has a "W" flag.  
##           Ask Mr. Google about these options.
##           Mr. Google is really smart.






#################################
## checking for data integrity ##
#################################
# 9) An option is uniquely defined by UnderlyingSymbol, Expiration
#    Type, Strike.  Let's make sure there is only one row per option.
##> df_daily %>% 
##>     group_by(
##>         UnderlyingSymbol
##>        , Expiration
##>         , Type
##>         , Strike
##>     ) %>% 
##>     summarize(opt_count = n()) %>%
##>     `$`(opt_count) %>% 
##>     max()





# 10) Let's make sure that the deltas are the right sign.
##> df_daily %>% 
##>     filter(
##>         (Type == "put" & Delta > 0) |
##>         (Type == "call" & Delta < 0)
##>     )





## Exercise: Brainstorm some other ideas of data integrity checks that you
##           could put in place.  Execute those data integrity checks.




###################
## SPY deep dive ##
###################
# 11) Let's isolate the SPY options.
##> df_spy <-
##>     df_daily %>% 
##>     filter(UnderlyingSymbol == "SPY")
##> View(df_spy)




# 12) Let's look at how many options there are per expiration for SPY.
##> df_spy %>%
##>     ggplot() +
##>     geom_bar(aes(x = factor(Expiration))) +
##>     theme(axis.text.x = element_text(angle = 45, hjust = 1))




## Note: There are expirations every M, W, F for a few weeks.
##       Then there is an expiration every week for a couple months.
##       After that there are monthly exirations untion 1/18/2019.
##       After that there are quarterly expirations until 12/18/2020.



# 13) Let's focus on the 9/21/2018 expiration for a moment.
##> df_spy_sep <- 
##>     df_spy %>%
##>     filter(Expiration == "2018-09-21")




# 14) Let's graph the prices for the puts and the calls. Note that these
#     are both 
##> ggplot() +
##>     geom_point(
##>         data = df_spy_sep %>% filter(Type == "put", between(Strike, 250, 315))
##>         , aes(x = Strike, y = Bid)
##>         , color = "blue"
##>     ) +
##>     geom_point(
##>         data = df_spy_sep %>% filter(Type == "call", between(Strike, 250, 315))
##>         , aes(x = Strike, y = Bid)
##>         , color = "red"
##>     )





# 15) Let's graph just the OTM option prices.
##> df_spy_sep %>% 
##>     filter(
##>         (Type == "put" & Strike < UnderlyingPrice) |
##>         (Type == "call" & Strike > UnderlyingPrice)
##>     ) %>%
##>     filter(between(Strike, 250, 315)) %>% 
##>     ggplot() +
##>         geom_point(aes(Strike, Bid, color = Type))


## Exercise: Graph the other greeks for the OTM options and make sure
##           that the graphs look similar to the one in the Options Part 4
##           lecture slides.




####################
## Data Wrangling ##
####################
# The purpose of this section is to give you a little insight as to a 
# bit of the data wrangling that needs to be done to this data to get
# it ready for back-testing (i.e. creating df_market_history).


# 16) Let's graph the implied vols for the Sep OTM options.
##> df_spy_sep %>% 
##>     filter(
##>         (Type == "put" & Strike < UnderlyingPrice) |
##>         (Type == "call" & Strike > UnderlyingPrice)
##>     ) %>%
##>     filter(between(Strike, 275, 290)) %>% 
##>     ggplot() +
##>     geom_point(aes(Strike, IVBid, color = Type))
    



# 17) There is a discontinuity in the implied vols.  This results from the
#     fact that they failed to account for dividend yield in their implied
#     volatility caclulation.  My remedy for this is to calculate the
#     implied_forward from the option prices and then to recalculate the
#     implied vols and the greeks.




# 18) Exercise: Graph the greeks (delta, vega, theta) and see that there is 
#               a similar discontinuity near the money.




# 19) Let's take a look at the OTM options with View().  Notice that for
#     deep OTM options, there are consecutive strikes with the same bid or
#     ask.  This results from minimum tick sizes in options markets.
#     My rememdy is to exclude all options with a strike beyond the first
#     instance of this, on both the call and put side.
##> df_spy_sep %>% 
##>     filter(
##>         (Type == "put" & Strike < UnderlyingPrice) |
##>         (Type == "call" & Strike > UnderlyingPrice)
##>     ) %>%
##>     arrange(Strike) %>% 
##>     View()




######################################
## Slices of the Volatility Surface ##
######################################
# 20) Since we have multiple expirations of SPY, let's use a facet 
#     wrap to graph skews for different time horizons simultaneously.
##> df_spy %>% 
##>     filter(between(Strike, 250, 315)) %>% 
##>     filter(
##>         (Type == "put" & Strike < UnderlyingPrice) |
##>             (Type == "call" & Strike > UnderlyingPrice)
##>     ) %>%
##>     filter(Expiration >= "2018-08-17") %>% 
##>     filter(IVBid > 0) %>% 
##>     ggplot() +
##>         geom_point(aes(x = Strike, y = IVBid), size = 0.25) +
##>         facet_wrap(~Expiration)



## Notice that the skews are most pronouced at nearby expirations, and that
## they flatten out for farther expiration.  This is consistent with the 
## fact that equity returns on long time scale are normal(ish). But 
## equity returns on a short time horizon are highly non-normal: fat-tailed, 
## with significant negative skew.














