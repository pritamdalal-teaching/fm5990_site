# fm5990_python_tutorials_and_exercises
tutorials and exercises for python portion of FM 5990
